/*
 * SpBrNonuiBase.h
 *
 *  Created on: 22 Tem 2011
 *      Author: ugur
 */

#ifndef SPBRNONUIBASE_H
#define SPBRNONUIBASE_H

#include "SpBrParcelable.h"

class SpBrNonuiBase: public SpBrParcelable {
public:
	SpBrNonuiBase();
	virtual ~SpBrNonuiBase();
};

#endif /* SPBRNONUIBASE_H */
